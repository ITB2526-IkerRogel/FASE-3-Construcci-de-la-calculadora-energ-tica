/**
 * Reduction.js — Versió amb protecció anti-duplicitat.
 */

(function () {
  'use strict';

  // PROTECCIÓ: Si el script ja s'ha executat, no fassis res més.
  if (window.ReductionCargado) return;
  window.ReductionCargado = true;

  const CURRENT_YEAR = new Date().getFullYear();
  let rawData = null;
  let indicadors = null;
  let totelesAccions = {};
  let selectedActions = new Set();

  document.addEventListener('DOMContentLoaded', async () => {
    // Netegem els contenidors abans de començar per si el HTML ja porta brossa
    const grid = document.getElementById('reduction-grid');
    if (grid) grid.innerHTML = '';

    setupNavigation();
    rawData = await Calculator.carregarDades();

    if (!rawData) {
      const main = document.querySelector('main.container-wide');
      if (main) main.innerHTML = `<div class="error-container"><h2>Error dades</h2></div>`;
      return;
    }

    indicadors = Calculator.processarTotsIndicadors(rawData);
    buildAccionsData();
    renderCentreName();
    renderImpactDashboard();
    renderReductionCards();
    updateImpact();
  });

  function setupNavigation() {
    const hamburger = document.querySelector('.nav-hamburger');
    const links = document.querySelector('.nav-links');
    if (hamburger && links) {
      // Fem servir onclick per evitar acumular múltiples listeners si es recarrega
      hamburger.onclick = () => links.classList.toggle('open');
    }
  }

  function renderCentreName() {
    const el = document.getElementById('centre-name');
    if (el && rawData.centre) el.textContent = rawData.centre;
  }

  function buildAccionsData() {
    totelesAccions = {
      consum_aigua: [
        { id: 'aigua_1', nom: 'Eliminació consum nocturn', desc: 'Reparar fuites (consum nocturn ~160 L/h).', reduccio: 25, inversio: 1500, circular: false },
        { id: 'aigua_2', nom: 'Aixetes baix cabal', desc: 'Instal·lar reductors de cabal als lavabos.', reduccio: 15, inversio: 2100, circular: false },
        { id: 'aigua_3', nom: 'Cisternes doble descàrrega', desc: 'Substituir cisternes per models de 3/6L.', reduccio: 10, inversio: 3200, circular: false },
        { id: 'aigua_4', nom: 'Recollida pluvial', desc: 'Sistema per a reg del jardí.', reduccio: 8, inversio: 5500, circular: true }
      ],
      consum_electric_solar: [
        { id: 'elec_1', nom: 'Ampliació panells solars', desc: 'Augmentar capacitat a 60 kWp.', reduccio: 15, inversio: 22000, circular: true },
        { id: 'elec_2', nom: 'Il·luminació LED', desc: 'Substitució per LED i sensors de presència.', reduccio: 12, inversio: 6500, circular: true },
        { id: 'elec_3', nom: 'Standby zero', desc: 'Apagada programada equips.', reduccio: 8, inversio: 800, circular: false },
        { id: 'elec_4', nom: 'Optimització HVAC', desc: 'Termòstats intel·ligents.', reduccio: 10, inversio: 4200, circular: false }
      ],
      consumibles_oficina: [
        { id: 'ofic_1', nom: 'Digitalització documental', desc: 'Gestió digital per reduir resmes.', reduccio: 20, inversio: 3500, circular: true },
        { id: 'ofic_2', nom: 'Impressió doble cara', desc: 'Configuració per defecte.', reduccio: 8, inversio: 0, circular: true },
        { id: 'ofic_3', nom: 'Retoladors recarregables', desc: 'Cartutxos recarregables eco.', reduccio: 5, inversio: 200, circular: true },
        { id: 'ofic_4', nom: 'Compra centralitzada', desc: 'Reduir costos d\'enviament.', reduccio: 5, inversio: 0, circular: true }
      ],
      productes_neteja: [
        { id: 'nete_1', nom: 'Assecadors d\'aire', desc: 'Substituir paper secamans.', reduccio: 15, inversio: 3600, circular: true },
        { id: 'nete_2', nom: 'Productes concentrats', desc: 'Canvi a productes eco concentrats.', reduccio: 10, inversio: 300, circular: true },
        { id: 'nete_3', nom: 'Dosificadors automàtics', desc: 'Evitar malbaratament de sabó.', reduccio: 8, inversio: 1200, circular: false },
        { id: 'nete_4', nom: 'Microfibra reutilitzable', desc: 'Substituir material d\'un sol ús.', reduccio: 7, inversio: 400, circular: true }
      ]
    };
  }

  function renderImpactDashboard() {
    const containers = document.querySelectorAll('.dashboard-column aside, #impact-dashboard');
    if (containers.length === 0) return;

    const dashboardHTML = `
      <div class="impact-dashboard-inner">
        <div class="impact-header" style="margin-bottom: var(--space-md);">
          <div style="display:flex; align-items:center; gap:10px;">
            <span style="font-size: 1.8rem;">🧮</span>
            <h3 style="margin:0;">Dashboard d'Impacte</h3>
          </div>
          <div class="impact-actions-bar" style="margin-top:10px; display:flex; gap:5px;">
            <button class="btn btn-sm btn-outline btn-select-all" style="flex:1;">✅ Tot</button>
            <button class="btn btn-sm btn-outline btn-deselect-all" style="flex:1;">❌ Res</button>
          </div>
        </div>
        <div class="impact-kpis" style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:var(--space-md);">
          <div class="impact-kpi" style="padding:10px; text-align:center; background:var(--bg-secondary); border-radius:var(--radius-sm);">
            <div class="impact-kpi-value" id="impact-savings" style="font-size:1.3rem; font-weight:800; color:var(--clean-green);">0 €</div>
            <div class="impact-kpi-label" style="font-size:0.7rem; color:var(--text-muted);">Estalvi Anual</div>
          </div>
          <div class="impact-kpi" style="padding:10px; text-align:center; background:var(--bg-secondary); border-radius:var(--radius-sm);">
            <div class="impact-kpi-value" id="impact-investment" style="font-size:1.3rem; font-weight:800; color:var(--solar-amber);">0 €</div>
            <div class="impact-kpi-label" style="font-size:0.7rem; color:var(--text-muted);">Inversió Total</div>
          </div>
        </div>
        <div class="impact-per-indicator" id="impact-per-indicator" style="display:flex; flex-direction:column; gap:8px;"></div>
      </div>
    `;

    containers.forEach(container => {
      container.innerHTML = dashboardHTML;

      container.querySelector('.btn-select-all').onclick = () => {
        document.querySelectorAll('.action-checkbox').forEach(cb => {
            cb.checked = true;
            selectedActions.add(cb.dataset.id);
        });
        updateImpact();
        updateVisualSelection();
      };

      container.querySelector('.btn-deselect-all').onclick = () => {
        document.querySelectorAll('.action-checkbox').forEach(cb => cb.checked = false);
        selectedActions.clear();
        updateImpact();
        updateVisualSelection();
      };
    });
  }

  function updateVisualSelection() {
    document.querySelectorAll('.interactive-action').forEach(item => {
      const cb = item.querySelector('.action-checkbox');
      if(cb) item.classList.toggle('selected', cb.checked);
    });
  }

  function updateImpact() {
    let totalSavings = 0;
    let totalInvestment = 0;
    let totalCircular = 0;
    let totalBaseCostAll = 0;

    const breakdownContainer = document.getElementById('impact-per-indicator');
    if (!breakdownContainer) return;

    let html = '';
    const keys = ['consum_aigua', 'consum_electric_solar', 'consumibles_oficina', 'productes_neteja'];

    keys.forEach(clau => {
      const ind = indicadors[clau];
      const accions = totelesAccions[clau];
      if (!ind || !accions) return;

      totalBaseCostAll += ind.totalCost;
      let indReduccio = 0, indInversio = 0, indSelected = 0;

      accions.forEach(a => {
        if (selectedActions.has(a.id)) {
          indReduccio += a.reduccio;
          indInversio += a.inversio;
          indSelected++;
          if (a.circular) totalCircular++;
        }
      });

      const effectiveReduccio = Math.min(indReduccio, 60);
      const estalvi = ind.totalCost * (effectiveReduccio / 100);
      totalSavings += estalvi;
      totalInvestment += indInversio;

      if (indSelected > 0) {
        const barWidth = (effectiveReduccio / 60) * 100;
        html += `
          <div class="impact-indicator-row" style="background:var(--bg-secondary); padding:10px; border-radius:var(--radius-md); margin-bottom:5px;">
            <div style="display:flex; justify-content:space-between; font-size:0.8rem; font-weight:600;">
              <span>${ind.icona} ${ind.nom}</span>
              <span style="color:var(--clean-green);">-${effectiveReduccio}%</span>
            </div>
            <div style="height:4px; background:var(--bg-primary); margin-top:5px; border-radius:2px;">
              <div style="width:${barWidth}%; height:100%; background:var(--clean-green);"></div>
            </div>
          </div>`;
      }

      const summary = document.getElementById(`card-summary-${clau}`);
      if (summary) {
        summary.innerHTML = indSelected > 0
          ? `<small style="color:var(--clean-green)">✅ ${indSelected} active</small>`
          : `<small style="color:var(--text-muted)">None</small>`;
      }
    });

    breakdownContainer.innerHTML = html;

    const savEl = document.getElementById('impact-savings');
    const invEl = document.getElementById('impact-investment');
    if(savEl) savEl.textContent = Calculator.formatCurrency(totalSavings);
    if(invEl) invEl.textContent = Calculator.formatCurrency(totalInvestment);

    const globalRed = totalBaseCostAll > 0 ? (totalSavings / totalBaseCostAll) * 100 : 0;
    const redEl = document.getElementById('stat-reduccio');
    if(redEl) redEl.textContent = `-${globalRed.toFixed(1)}%`;

    const accEl = document.getElementById('stat-accions');
    if(accEl) accEl.textContent = selectedActions.size;
  }

  function renderReductionCards() {
    const grid = document.getElementById('reduction-grid');
    if (!grid) return;

    grid.innerHTML = ''; // NETEJA ABSOLUTA
    let html = '';
    const keys = ['consum_aigua', 'consum_electric_solar', 'consumibles_oficina', 'productes_neteja'];

    keys.forEach(clau => {
      const ind = indicadors[clau];
      const accions = totelesAccions[clau];
      html += `
        <div class="reduction-card" style="margin-bottom:20px; background:var(--bg-card); border-radius:12px; border:1px solid var(--border-color); overflow:hidden;">
          <div style="padding:15px; background:rgba(0,0,0,0.02); display:flex; justify-content:space-between; align-items:center;">
            <h3 style="margin:0;">${ind.icona} ${ind.nom}</h3>
            <div id="card-summary-${clau}"></div>
          </div>
          <div style="padding:10px;">
            ${accions.map(a => `
              <div class="action-item interactive-action" data-id="${a.id}" style="padding:10px; display:flex; gap:10px; cursor:pointer;">
                <input type="checkbox" class="action-checkbox" data-id="${a.id}" ${selectedActions.has(a.id) ? 'checked' : ''}>
                <div style="flex:1;">
                  <div style="font-weight:600; font-size:0.9rem;">${a.nom}</div>
                  <div style="font-size:0.8rem; color:var(--text-muted);">${a.desc}</div>
                </div>
              </div>
            `).join('')}
          </div>
        </div>`;
    });
    grid.innerHTML = html;

    grid.querySelectorAll('.interactive-action').forEach(item => {
      const cb = item.querySelector('.action-checkbox');
      item.onclick = (e) => {
        if (e.target !== cb) {
          cb.checked = !cb.checked;
          cb.dispatchEvent(new Event('change'));
        }
      };
      cb.onchange = (e) => {
        const id = e.target.dataset.id;
        if (e.target.checked) selectedActions.add(id);
        else selectedActions.delete(id);
        updateImpact();
        updateVisualSelection();
      };
    });
  }

})();